import Alpine from "alpinejs";
import screen from "@victoryoalli/alpinejs-screen";

Alpine.plugin(screen);

window.Alpine = Alpine;

Alpine.start();
