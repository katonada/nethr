---
id: bd177cc0-23f9-40b2-a106-fa4b6aa4f37c
blueprint: page
title: Contact
updated_by: 5019d32a-932e-4e80-9d30-b60b20e24e87
updated_at: 1688221443
blocks:
  -
    id: ljhojgwl
    rich_text:
      -
        type: heading
        attrs:
          level: 2
        content:
          -
            type: text
            marks:
              -
                type: bold
            text: 'Contact Blogo'
      -
        type: paragraph
        content:
          -
            type: text
            text: 'Have something to say? We are here to help. Fill up the form or send email or call phone.'
    type: contact_section
    enabled: true
    contact_info:
      -
        id: ljk2hja8
        select_type: location
        text: '1434 Earth, 23063'
        type: contact
        enabled: true
        icon: location
      -
        id: ljk2ioyg
        select_type: email
        text: hello@example.com
        type: contact
        enabled: true
        icon: email
      -
        id: ljk2iyyw
        select_type: phone
        text: '+1 (987) 4587 899'
        type: contact
        enabled: true
        icon: phone
show_title: true
---
