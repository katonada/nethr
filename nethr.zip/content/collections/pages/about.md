---
id: 104870a0-11c3-4766-9fa7-00d59ecafe13
blueprint: page
title: About
updated_by: 5019d32a-932e-4e80-9d30-b60b20e24e87
updated_at: 1688217621
blocks:
  -
    id: ljjycedd
    content:
      -
        type: paragraph
        attrs:
          textAlign: left
        content:
          -
            type: text
            text: 'It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.'
      -
        type: set
        attrs:
          id: ljk0lv5h
          values:
            type: image
            image: post_3.png
      -
        type: paragraph
        attrs:
          textAlign: left
        content:
          -
            type: text
            marks:
              -
                type: bold
            text: 'Lorem Ipsum'
          -
            type: text
            text: " is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. "
      -
        type: horizontalRule
      -
        type: paragraph
        attrs:
          textAlign: left
        content:
          -
            type: text
            text: 'It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. '
    type: content
    enabled: true
show_title: true
---
