---
id: home
blueprint: pages
title: Home
template: home
updated_by: 718f20f4-e54d-45dc-8b1d-e62ddc6e87b5
updated_at: 1731327665
blocks:
  -
    id: ljj7lhk3
    featured_post: c1c767f1-9097-4d7e-a3ae-78cce87cee82
    type: featured_post
    enabled: true
    background_color: '#000000'
  -
    id: ljjwxa54
    featured_posts:
      - 92f664b5-bb83-4bb4-94c0-adc915db3ca0
      - cbdca493-761c-4bd9-aa3d-0930f7cd9f3b
    type: featured_posts
    enabled: true
show_title: false
template_field: home
---
## Welcome to your brand new Statamic site!

Not sure where to do next? Here are a few ideas, but feel free to explore in your own way, in your own time.

- [Jump into the Control Panel](/cp) and edit this page or begin setting up your own collections and blueprints.
- [Head to the docs](https://statamic.dev) and learn how Statamic works.
- [Watch some Statamic videos](https://youtube.com/statamic) on YouTube.
- [Join our Discord chat](https://statamic.com/discord) and meet thousands of other Statamic developers.
- [Start a discussion](https://github.com/statamic/cms/discussions) and get answers to your questions.
- [Star Statamic on Github](https://github.com/statamic/cms) if you enjoy using it!
